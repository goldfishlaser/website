**********************************************************************

  MIDITrail for Mac OS X

  Copyright (C) 2010-2013 WADA Masashi. All Rights Reserved.

  Web : http://sourceforge.jp/projects/miditrail/
  Mail: yknk@users.sourceforge.jp

**********************************************************************

(1) Introduction

  MIDITrail is a MIDI player which provides 3D visualization of
  MIDI datasets. MIDITrail supports SMF format 0/1, and multiple
  MIDI ports.

(2) System requirement

  OS : Mac OS X 10.5 (Leopard), 10.6 (Snow Leopard), 10.7 (Lion), 10.8(Mountain Lion), 10.9(Mavericks)
  CPU: intel CPU (MIDITrail has no support for PowerPC)

(3) Quick Start

  1. Execute MIDITrail.
  2. Drop Standard MIDI file (*.mid) to the window.
  3. Push space key to play/pause, and push ESC key to stop.

(4) User manual

  Please check "Help" -> "Manual…".


