**********************************************************************

  MIDITrail for Mac OS X

  Copyright (C) 2010-2013 WADA Masashi. All Rights Reserved.

  Web : http://sourceforge.jp/projects/miditrail/
  Mail: yknk@users.sourceforge.jp

**********************************************************************

(1) はじめに

  MIDITrailはMIDIデータを三次元可視化するMIDIプレーヤーです。
  標準MIDIファイルFormat0/1、および複数ポート出力に対応しています。

(2) 動作環境

  OS : Mac OS X 10.5 (Leopard), 10.6 (Snow Leopard), 10.7 (Lion), 10.8(Mountain Lion), 10.9(Mavericks)
  CPU: intel CPU (MIDITrailはPowerPCをサポートしていません)

(3) クイックスタート

  1. MIDITrailを起動してください。
  2. 標準MIDIファイル(*.mid)をウィンドウにドロップしてください。
  3. スペースキーで演奏開始／一時停止、ESCキーで演奏停止します。

(4) ユーザーマニュアル

  "Help" -> "Manual…"を参照してください。


